#pragma once

typedef struct {
	char name[20];
	int coin;
}USER;

typedef struct {
	USER data;
	struct NODE* next;
}NODE_U;

typedef struct {
	int count;
	NODE_U* head;
	NODE_U* tail;
}LIST_U;

void useradd(LIST_U* plist, USER** manager);
void userlist(LIST_U* plist, USER* manager);
void chuser(LIST_U* plist, USER** manager);
void getuser(USER* manager);

