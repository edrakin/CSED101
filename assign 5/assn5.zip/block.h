#pragma once
#include"user.h"
#include"trans.h"

typedef struct {
	TRANS trans[3];
	TRANS special;
	int trans_num;
}BLOCK;

typedef struct {
	BLOCK data;
	struct NODE* next;
}NODE_B;

typedef struct {
	int count;
	NODE_B* head;
	NODE_B* tail;
}LIST_B;


void mkgenblk(USER* manager, LIST_B* blist, USER* nothing);
void mkblk(USER* manager, LIST_B* blist, LIST_U* ulist, LIST_T* tlist, USER* nothing);
void blklist(LIST_B* blist);
int Y_N(USER* already, NODE_T* t, int count);
void freeing(LIST_T* tlist, NODE_T* t);


