#pragma once
#include"user.h"

typedef struct {
	USER* sender;
	USER* receiver;
	int trans_coin;
}TRANS;

typedef struct {
	TRANS data;
	struct NODE* next;
}NODE_T;

typedef struct {
	int count;
	NODE_T* head;
	NODE_T* tail;
}LIST_T;

void mktx(USER* manager, LIST_T* tlist, LIST_U* ulist);
void txlist(LIST_T* plist);


