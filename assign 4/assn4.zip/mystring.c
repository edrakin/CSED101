#include <stddef.h>


int mystrlen(char *str)
{
	int i=0;
	while(*(str+i))
	{
		i++;
	}
	return i;
}

char* mystrcpy(char *toStr, char *fromStr)
{
	int i=0;
	while(*(fromStr+i))
	{
		*(toStr+i) = *(fromStr+i);
		i++;
	}
	*(toStr+i) ="\0";
	return toStr;
}

int mystrcmp(char *str1, char *str2)
{
	int i=0;
	while(str1[i]==str2[i])
	{
		i++;
		if(str1[i]=="\0"||str2[i]=="\0")
			return 0;
	}
	if (str1[i]>str2[i])
		return 1;
	else 
		return -1;
}

char *	mystrcat(char *dest, char *src)
{
	int i=0, j=0, k;
	while(dest[i])
	{
		i++;
	 } 
	while(src[j])
	{
		j++;
	 } 
	for(k=0;k<j;k++)
	{
		dest[i+k]=src[k];
	}
	dest[i+j+1]="\0";
	return dest;
}

char *mystrrchr(char *str, char c)
{
	int i=0;
	char* checkpoint=NULL;
	while(str[i])
	{
		if (str[i]==c)
			checkpoint = str+i;
	}
	return checkpoint;
}
