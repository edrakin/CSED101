#include <stddef.h>

int mystrlen(char *str)
{
	// Insert your code 
}

char *mystrcpy(char *toStr, char *fromStr)
{
	// Insert your code 
}

int mystrcmp(char *str1, char *str2)
{
	// Insert your code 
}

char *mystrcat(char *dest, char *src)
{
	// Insert your code 
}

char *mystrrchr(char *str, char c)
{
	// Insert your code
}
