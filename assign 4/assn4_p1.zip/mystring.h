#pragma once

int mystrlen(char *str);
char *mystrcpy(char *toStr, char *fromStr);
int mystrcmp(char *str1, char *str2);
char *mystrcat(char *dest, char *src);
char *mystrrchr(char *str, char c);
